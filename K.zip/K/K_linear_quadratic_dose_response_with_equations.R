# ================================================================
# Linear vs quadratic dose-response meta-regression for condition factor (K)
# Topic: Fishmeal (FM) replacement by BSF meal in rainbow trout
# Outcome: condition factor (K) using existing Hedges' g and Variance columns
# Sheets: K, K_L, K_Whole
#
# This version is designed to match the manuscript criterion:
# 1) Fit BOTH linear and quadratic meta-regression models.
# 2) Test the quadratic term beta2, p < 0.05.
# 3) Compare AIC between linear and quadratic models; Delta AIC > 2 is meaningful.
# 4) Retain quadratic only when it is statistically supported AND has a biologically
#    interpretable internal optimum/threshold candidate. Final biological judgement
#    must still be checked by the researcher before manuscript reporting.
# 5) Insert the selected/candidate model equations and intercept values directly
#    inside the generated dose-response graphs.
#
# Notes:
# - AIC comparison is performed using ML-fitted models because fixed-effect
#   structures differ between the linear and quadratic models.
# - Final coefficient estimates are reported from REML-fitted models.
# - For condition factor (K), Hedges' g > 0 indicates higher K in the BSF group
#   than the control group, whereas Hedges' g < 0 indicates lower K.
# ================================================================

# ---- 1. Packages ----

library(readxl)
library(dplyr)
library(tidyr)
library(purrr)
library(stringr)
library(janitor)
library(metafor)
library(ggplot2)
library(patchwork)
library(readr)
library(scales)
library(clubSandwich)

# ---- 2. User settings ----
# Put the Excel file in your R working directory or replace this path.
file_path <- "~/Oncorhynchus mykiss/Biometrices indices.xlsx"

out_dir <- "K_linear_quadratic_dose_response_equation_outputs"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

sheet_info <- tibble::tribble(
  ~sheet,       ~dataset_label,                ~subset_type,
  "K",         "Full dataset",                "Full dataset",
  "K_L",       "Larvae",                      "Development stage subset",
  "K_Whole",   "Whole/full-fat BSF",          "Processing method subset"
)

# Main continuous moderator. The requested dose-response moderator is % FM replacement by BSF.
# To analyse dietary BSF inclusion instead, change this to: moderator_var <- "bsf_inclusion"
moderator_var <- "fm_replacement"
moderator_axis_label <- "% fishmeal replacement by BSF meal"

# Model-selection thresholds matching the manuscript wording.
alpha_quad <- 0.05
meaningful_delta_aic <- 2

# Colour-blind-safe publication palette.
processing_palette <- c(
  "Whole/full-fat" = "#0072B2",
  "Partially defatted" = "#E69F00",
  "Defatted" = "#D55E00",
  "Mixed/unknown" = "#666666"
)
selected_line_colour <- "#004C6D"
selected_ribbon_colour <- "#004C6D"
comparison_palette <- c(
  "Linear" = "#0072B2",
  "Quadratic" = "#D55E00"
)

# ---- 3. Helper functions ----
num <- function(x) suppressWarnings(as.numeric(x))

compact_name <- function(x) {
  x %>%
    stringr::str_to_lower() %>%
    stringr::str_replace_all("[^a-z0-9]", "")
}

find_col <- function(dat, candidates, label, sheet, required = TRUE) {
  nms <- names(dat)

  exact_hit <- intersect(candidates, nms)
  if (length(exact_hit) > 0) return(exact_hit[1])

  nms_compact <- compact_name(nms)
  cand_compact <- compact_name(candidates)
  compact_hit <- which(nms_compact %in% cand_compact)
  if (length(compact_hit) > 0) return(nms[compact_hit[1]])

  if (required) {
    stop(
      paste0(
        "Sheet '", sheet, "' is missing required column for ", label, ".\n",
        "Expected one of: ", paste(candidates, collapse = ", "), "\n",
        "Available cleaned column names are: ", paste(nms, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  NA_character_
}

clean_study_id <- function(author, year) {
  id <- as.character(author)
  id <- stringr::str_replace(id, "_\\d+$", "")
  id <- stringr::str_squish(id)
  id <- ifelse(is.na(id) | id == "", paste0("Unknown_", year), id)
  id
}

present_value <- function(x) {
  !is.na(x) & stringr::str_squish(as.character(x)) != ""
}

optional_chr_col <- function(dat, col) {
  if (col %in% names(dat)) {
    as.character(dat[[col]])
  } else {
    rep(NA_character_, nrow(dat))
  }
}

# Processing classification rule:
# - For K_Whole, the sheet itself defines the processing group.
# - For K and K_L, indicator columns are used only to decide broad groups.
# - Text variants such as "Whole", "whole enriched", and similar are collapsed.
assign_processing_by_sheet <- function(dat, sheet) {
  if (sheet == "K_Whole") {
    return(rep("Whole/full-fat", nrow(dat)))
  }

  whole_col <- optional_chr_col(dat, "whole")
  pd_col <- optional_chr_col(dat, "partially_defatted")
  d_col <- optional_chr_col(dat, "defatted")

  dplyr::case_when(
    present_value(whole_col) ~ "Whole/full-fat",
    present_value(pd_col) ~ "Partially defatted",
    present_value(d_col) ~ "Defatted",
    TRUE ~ "Mixed/unknown"
  )
}

read_k_sheet <- function(sheet, dataset_label, subset_type) {
  raw <- readxl::read_excel(file_path, sheet = sheet) %>%
    janitor::clean_names()

  author_col <- find_col(raw, c("author"), "Author", sheet)
  year_col <- find_col(raw, c("year"), "Year", sheet)
  fm_col <- find_col(
    raw,
    c("fm_replacement", "fishmeal_replacement", "fish_meal_replacement", "fmreplacement"),
    "FM replacement", sheet
  )
  bsf_col <- find_col(
    raw,
    c("bsf_inclusion", "bsf_inclusion_percent", "bsf_inclusion_level", "bsfinclusion"),
    "BSF inclusion", sheet,
    required = FALSE
  )
  hedges_col <- find_col(
    raw,
    c("hedges_s_g", "hedges_g", "hedges__g", "hedgessg", "hedgesg", "hedges_sg"),
    "Hedges' g", sheet
  )
  variance_col <- find_col(raw, c("variance", "vi", "var", "sampling_variance"), "Variance", sheet)

  processing_vec <- assign_processing_by_sheet(raw, sheet)

  dat <- raw %>%
    mutate(
      sheet = sheet,
      dataset = dataset_label,
      subset_type = subset_type,
      row_id = row_number(),
      effect_id = paste(sheet, row_id, sep = "_"),
      author_std = .data[[author_col]],
      year_std = .data[[year_col]],
      study_id = clean_study_id(author_std, year_std),
      fm_replacement_std = num(.data[[fm_col]]),
      bsf_inclusion_std = if (!is.na(bsf_col)) num(.data[[bsf_col]]) else NA_real_,
      dose = dplyr::case_when(
        moderator_var == "fm_replacement" ~ fm_replacement_std,
        moderator_var == "bsf_inclusion" ~ bsf_inclusion_std,
        TRUE ~ NA_real_
      ),
      yi = num(.data[[hedges_col]]),
      vi = num(.data[[variance_col]]),
      se = sqrt(vi),
      precision = 1 / se,
      processing = factor(
        processing_vec,
        levels = c("Whole/full-fat", "Partially defatted", "Defatted", "Mixed/unknown")
      )
    ) %>%
    filter(is.finite(dose), is.finite(yi), is.finite(vi), vi > 0)

  message(sheet, ": retained ", nrow(dat), " usable comparisons from ",
          dplyr::n_distinct(dat$study_id), " study cluster(s).")
  message(sheet, ": Hedges' g column detected as '", hedges_col, "'.")
  message(sheet, ": processing labels used = ", paste(unique(as.character(dat$processing)), collapse = ", "))

  dat
}

prepare_model_data <- function(dat) {
  dat %>%
    mutate(
      dose_mean = mean(dose, na.rm = TRUE),
      dose_min = min(dose, na.rm = TRUE),
      dose_max = max(dose, na.rm = TRUE),
      dose10_c = (dose - dose_mean) / 10,
      dose10_c2 = dose10_c^2
    )
}

fit_meta_model <- function(dat, model_type = c("linear", "quadratic"), method = c("REML", "ML")) {
  model_type <- match.arg(model_type)
  method <- match.arg(method)

  if (model_type == "linear") {
    if (nrow(dat) < 3 || dplyr::n_distinct(dat$dose) < 2) {
      stop("Linear meta-regression requires at least 3 effects and at least 2 unique moderator levels.", call. = FALSE)
    }
    mods_formula <- ~ dose10_c
  } else {
    if (nrow(dat) < 5 || dplyr::n_distinct(dat$dose) < 3) {
      return(NULL)
    }
    mods_formula <- ~ dose10_c + dose10_c2
  }

  metafor::rma.mv(
    yi = yi,
    V = vi,
    mods = mods_formula,
    random = ~ 1 | study_id / effect_id,
    method = method,
    data = dat,
    test = "t",
    control = list(optimizer = "optim")
  )
}

get_aic <- function(mod) {
  if (is.null(mod)) return(NA_real_)
  as.numeric(stats::AIC(mod))
}

safe_coef_summary <- function(mod) {
  if (is.null(mod)) return(NULL)
  as.data.frame(coef(summary(mod)))
}

get_term_value <- function(sm, term, col) {
  if (is.null(sm) || !(term %in% rownames(sm)) || !(col %in% names(sm))) {
    return(NA_real_)
  }
  as.numeric(sm[term, col])
}

extract_cr2_table <- function(mod, dat) {
  if (is.null(mod) || !requireNamespace("clubSandwich", quietly = TRUE)) {
    return(NULL)
  }
  tryCatch(
    {
      rb <- clubSandwich::coef_test(mod, vcov = "CR2", cluster = dat$study_id)
      tibble::tibble(
        term = rownames(rb),
        robust_estimate_CR2 = rb$beta,
        robust_se_CR2 = rb$SE,
        robust_df_Satt_CR2 = rb$df_Satt,
        robust_p_value_CR2 = rb$p_Satt
      )
    },
    error = function(e) NULL
  )
}

extract_model_coefficients <- function(sheet, dataset_label, subset_type, model_label, mod, dat) {
  sm <- safe_coef_summary(mod)
  if (is.null(sm)) return(tibble())

  tab <- sm %>%
    tibble::rownames_to_column("term") %>%
    transmute(
      sheet = sheet,
      dataset = dataset_label,
      subset_type = subset_type,
      model = model_label,
      term = term,
      estimate = estimate,
      se = se,
      ci_lb = ci.lb,
      ci_ub = ci.ub,
      p_value = pval,
      k = nrow(dat),
      n_study_clusters = n_distinct(dat$study_id),
      AIC_REML = get_aic(mod),
      sigma2_study = ifelse(length(mod$sigma2) >= 1, mod$sigma2[1], NA_real_),
      sigma2_effect_within_study = ifelse(length(mod$sigma2) >= 2, mod$sigma2[2], NA_real_),
      QE = mod$QE,
      QE_p_value = mod$QEp
    )

  rb <- extract_cr2_table(mod, dat)
  if (!is.null(rb)) {
    tab <- tab %>% left_join(rb, by = "term")
  }

  tab
}

select_linear_vs_quadratic <- function(sheet, dataset_label, subset_type, dat, linear_reml, quadratic_reml, linear_ml, quadratic_ml) {
  lin_aic_ml <- get_aic(linear_ml)
  quad_aic_ml <- get_aic(quadratic_ml)
  delta_aic_linear_minus_quadratic <- lin_aic_ml - quad_aic_ml

  qsm <- safe_coef_summary(quadratic_reml)
  beta1 <- get_term_value(qsm, "dose10_c", "estimate")
  beta2 <- get_term_value(qsm, "dose10_c2", "estimate")
  beta2_se <- get_term_value(qsm, "dose10_c2", "se")
  beta2_ci_lb <- get_term_value(qsm, "dose10_c2", "ci.lb")
  beta2_ci_ub <- get_term_value(qsm, "dose10_c2", "ci.ub")
  beta2_p <- get_term_value(qsm, "dose10_c2", "pval")

  dose_mean <- mean(dat$dose, na.rm = TRUE)
  dose_min <- min(dat$dose, na.rm = TRUE)
  dose_max <- max(dat$dose, na.rm = TRUE)

  turning_point_dose <- ifelse(
    is.finite(beta1) && is.finite(beta2) && beta2 != 0,
    dose_mean + 10 * (-beta1 / (2 * beta2)),
    NA_real_
  )

  turning_point_in_observed_range <- is.finite(turning_point_dose) &&
    turning_point_dose >= dose_min && turning_point_dose <= dose_max

  # For condition factor (K), higher effect size generally indicates a higher body-condition index.
  # A negative quadratic coefficient gives an inverted-U curve, and an internal vertex may represent
  # a candidate optimum replacement level. A positive quadratic coefficient gives a U-shaped curve
  # with an internal minimum/threshold candidate that requires cautious biological interpretation.
  candidate_k_optimum <- isTRUE(turning_point_in_observed_range) && is.finite(beta2) && beta2 < 0
  candidate_internal_threshold <- isTRUE(turning_point_in_observed_range) && is.finite(beta2)

  quadratic_term_significant <- is.finite(beta2_p) && beta2_p < alpha_quad
  quadratic_aic_preferred <- is.finite(delta_aic_linear_minus_quadratic) &&
    delta_aic_linear_minus_quadratic > meaningful_delta_aic
  linear_aic_preferred <- is.finite(delta_aic_linear_minus_quadratic) &&
    delta_aic_linear_minus_quadratic < -meaningful_delta_aic
  aic_equivocal <- is.finite(delta_aic_linear_minus_quadratic) &&
    abs(delta_aic_linear_minus_quadratic) <= meaningful_delta_aic

  biological_candidate_auto <- candidate_internal_threshold

  selected_model_statistical <- dplyr::case_when(
    is.null(quadratic_reml) ~ "Linear retained: quadratic model not estimable",
    quadratic_term_significant & quadratic_aic_preferred ~ "Quadratic statistically preferred; biological justification required",
    !quadratic_term_significant & aic_equivocal ~ "Linear retained: quadratic term non-significant and Delta AIC < 2",
    !quadratic_term_significant ~ "Linear retained: quadratic term non-significant",
    linear_aic_preferred ~ "Linear retained: AIC favours linear model",
    aic_equivocal ~ "Linear retained: Delta AIC <= 2, so parsimonious linear model preferred",
    TRUE ~ "Linear retained by parsimony or requires manual review"
  )

  selected_model_script_default <- dplyr::case_when(
    !is.null(quadratic_reml) & quadratic_term_significant & quadratic_aic_preferred & biological_candidate_auto ~ "quadratic",
    TRUE ~ "linear"
  )

  biological_plausibility_note <- dplyr::case_when(
    is.null(quadratic_reml) ~ "Not assessed because quadratic model was not estimable.",
    candidate_k_optimum ~ "Candidate K optimum: negative curvature and internal maximum within observed dose range. Check whether this dose is biologically interpretable before manuscript reporting.",
    candidate_internal_threshold ~ "Candidate internal turning point/threshold within observed dose range. Requires biological justification before reporting as quadratic.",
    TRUE ~ "No internal optimum/threshold within observed dose range; biological support for quadratic form is weak."
  )

  tibble(
    sheet = sheet,
    dataset = dataset_label,
    subset_type = subset_type,
    moderator = moderator_var,
    k = nrow(dat),
    n_study_clusters = n_distinct(dat$study_id),
    n_unique_doses = n_distinct(dat$dose),
    dose_min = dose_min,
    dose_max = dose_max,
    AIC_linear_ML = lin_aic_ml,
    AIC_quadratic_ML = quad_aic_ml,
    delta_AIC_linear_minus_quadratic = delta_aic_linear_minus_quadratic,
    AIC_interpretation = dplyr::case_when(
      is.na(delta_aic_linear_minus_quadratic) ~ "Quadratic AIC unavailable",
      delta_aic_linear_minus_quadratic > meaningful_delta_aic ~ "Quadratic AIC lower by > 2",
      delta_aic_linear_minus_quadratic < -meaningful_delta_aic ~ "Linear AIC lower by > 2",
      TRUE ~ "Delta AIC <= 2; no meaningful AIC separation"
    ),
    beta2_quadratic_estimate_per_10pct_squared = beta2,
    beta2_quadratic_se = beta2_se,
    beta2_quadratic_ci_lb = beta2_ci_lb,
    beta2_quadratic_ci_ub = beta2_ci_ub,
    beta2_quadratic_p_value = beta2_p,
    quadratic_term_significant_p_lt_0_05 = quadratic_term_significant,
    quadratic_AIC_preferred_delta_gt_2 = quadratic_aic_preferred,
    turning_point_dose_percent_replacement = turning_point_dose,
    turning_point_in_observed_range = turning_point_in_observed_range,
    candidate_K_optimum = candidate_k_optimum,
    candidate_internal_threshold = candidate_internal_threshold,
    biological_plausibility_note = biological_plausibility_note,
    selected_model_statistical_rule = selected_model_statistical,
    selected_model_script_default = selected_model_script_default,
    manual_biological_plausibility_review_needed = !is.null(quadratic_reml) &&
      quadratic_term_significant && quadratic_aic_preferred
  )
}

run_model_selection <- function(dat) {
  dat_model <- prepare_model_data(dat)

  linear_reml <- fit_meta_model(dat_model, model_type = "linear", method = "REML")
  linear_ml <- fit_meta_model(dat_model, model_type = "linear", method = "ML")

  quadratic_reml <- fit_meta_model(dat_model, model_type = "quadratic", method = "REML")
  quadratic_ml <- fit_meta_model(dat_model, model_type = "quadratic", method = "ML")

  selection <- select_linear_vs_quadratic(
    sheet = dat_model$sheet[1],
    dataset_label = dat_model$dataset[1],
    subset_type = dat_model$subset_type[1],
    dat = dat_model,
    linear_reml = linear_reml,
    quadratic_reml = quadratic_reml,
    linear_ml = linear_ml,
    quadratic_ml = quadratic_ml
  )

  list(
    data_model = dat_model,
    linear_reml = linear_reml,
    quadratic_reml = quadratic_reml,
    linear_ml = linear_ml,
    quadratic_ml = quadratic_ml,
    selection = selection
  )
}

predict_meta_model <- function(mod, dat, model_type = c("linear", "quadratic"), n = 200) {
  model_type <- match.arg(model_type)

  grid <- tibble(
    dose = seq(min(dat$dose, na.rm = TRUE), max(dat$dose, na.rm = TRUE), length.out = n)
  )

  z <- (grid$dose - mean(dat$dose, na.rm = TRUE)) / 10
  newmods <- if (model_type == "linear") {
    matrix(z, ncol = 1)
  } else {
    cbind(z, z^2)
  }

  pr <- predict(mod, newmods = newmods)

  bind_cols(
    grid,
    tibble(pred = pr$pred, ci_lb = pr$ci.lb, ci_ub = pr$ci.ub)
  )
}

format_p <- function(p) {
  dplyr::case_when(
    is.na(p) ~ "NA",
    p < 0.001 ~ "<0.001",
    TRUE ~ sprintf("%.3f", p)
  )
}

format_delta_aic <- function(x) {
  ifelse(is.na(x), "NA", sprintf("%.2f", x))
}

# Format coefficients for compact graph labels.
fmt_coef <- function(x, digits = 4) {
  ifelse(
    is.na(x) | !is.finite(x),
    "NA",
    ifelse(
      x != 0 & abs(x) < 0.0001,
      formatC(x, format = "e", digits = 2),
      sprintf(paste0("%.", digits, "f"), x)
    )
  )
}

fmt_coef_abs <- function(x, digits = 4) {
  fmt_coef(abs(x), digits = digits)
}

fmt_signed_term <- function(x, suffix = "", digits = 4) {
  if (is.na(x) | !is.finite(x)) {
    return(paste0("+ NA", suffix))
  }
  if (x < 0) {
    paste0("- ", fmt_coef_abs(x, digits = digits), suffix)
  } else {
    paste0("+ ", fmt_coef_abs(x, digits = digits), suffix)
  }
}

get_named_coef <- function(b, term, fallback_index) {
  if (term %in% names(b)) {
    return(as.numeric(b[[term]]))
  }
  if (length(b) >= fallback_index) {
    return(as.numeric(b[[fallback_index]]))
  }
  NA_real_
}

# Converts the fitted centered model into a raw-dose equation for display:
# x = FM replacement (%)
# Linear model fitted as:     yi = b0 + b1 * ((x - mean(x)) / 10)
# Quadratic model fitted as:  yi = b0 + b1 * ((x - mean(x)) / 10) + b2 * ((x - mean(x)) / 10)^2
# Displayed as:              g_hat = a + b*x + c*x^2
get_equation_components <- function(mod, dat, model_type = c("linear", "quadratic")) {
  model_type <- match.arg(model_type)
  if (is.null(mod)) return(NULL)

  b <- stats::coef(mod)
  dose_mean <- mean(dat$dose, na.rm = TRUE)
  dose_min <- min(dat$dose, na.rm = TRUE)
  dose_max <- max(dat$dose, na.rm = TRUE)

  b0 <- get_named_coef(b, "intrcpt", 1)
  if (is.na(b0)) b0 <- get_named_coef(b, "(Intercept)", 1)
  b1 <- get_named_coef(b, "dose10_c", 2)
  b2 <- if (model_type == "quadratic") get_named_coef(b, "dose10_c2", 3) else 0

  if (model_type == "linear") {
    raw_intercept <- b0 - (b1 * dose_mean / 10)
    raw_linear <- b1 / 10
    raw_quadratic <- 0
  } else {
    raw_intercept <- b0 - (b1 * dose_mean / 10) + (b2 * dose_mean^2 / 100)
    raw_linear <- (b1 / 10) - (2 * b2 * dose_mean / 100)
    raw_quadratic <- b2 / 100
  }

  tibble::tibble(
    model = model_type,
    centered_intercept_at_mean_dose = b0,
    centered_beta1_per_10pct = b1,
    centered_beta2_per_10pct_squared = ifelse(model_type == "quadratic", b2, NA_real_),
    mean_dose_percent = dose_mean,
    dose_min_percent = dose_min,
    dose_max_percent = dose_max,
    raw_intercept_at_0pct = raw_intercept,
    raw_linear_slope_per_1pct = raw_linear,
    raw_quadratic_per_1pct_squared = ifelse(model_type == "quadratic", raw_quadratic, NA_real_),
    intercept_0pct_observed_or_extrapolated = ifelse(
      0 >= dose_min & 0 <= dose_max,
      "0% is within observed dose range",
      "0% is outside observed dose range; intercept is extrapolated"
    )
  )
}

make_equation_text <- function(mod, dat, model_type = c("linear", "quadratic"),
                               sel = NULL, brief = FALSE) {
  model_type <- match.arg(model_type)
  comp <- get_equation_components(mod, dat, model_type)

  if (is.null(comp)) {
    return("Quadratic: not estimable")
  }

  if (model_type == "linear") {
    eq <- paste0(
      "Linear: g_hat = ", fmt_coef(comp$raw_intercept_at_0pct), " ",
      fmt_signed_term(comp$raw_linear_slope_per_1pct, "x")
    )
  } else {
    eq <- paste0(
      "Quadratic: g_hat = ", fmt_coef(comp$raw_intercept_at_0pct), " ",
      fmt_signed_term(comp$raw_linear_slope_per_1pct, "x"), " ",
      fmt_signed_term(comp$raw_quadratic_per_1pct_squared, "x^2")
    )
  }

  intercept_txt <- paste0(
    "Intercept at x=0: ", fmt_coef(comp$raw_intercept_at_0pct),
    "; intercept at mean x=", sprintf("%.1f", comp$mean_dose_percent),
    "%: ", fmt_coef(comp$centered_intercept_at_mean_dose)
  )

  if (brief) {
    return(paste(eq, intercept_txt, sep = "\n"))
  }

  stats_txt <- if (!is.null(sel)) {
    if (model_type == "quadratic") {
      paste0(
        "beta2 p=", format_p(sel$beta2_quadratic_p_value),
        "; Delta AIC=", format_delta_aic(sel$delta_AIC_linear_minus_quadratic)
      )
    } else {
      paste0(
        "Delta AIC(linear - quadratic)=", format_delta_aic(sel$delta_AIC_linear_minus_quadratic)
      )
    }
  } else {
    NULL
  }

  paste(
    "x = FM replacement (%)",
    eq,
    intercept_txt,
    stats_txt,
    sep = "\n"
  )
}

get_label_position <- function(dat, pred = NULL) {
  x_values <- dat$dose
  y_values <- dat$yi

  if (!is.null(pred)) {
    x_values <- c(x_values, pred$dose)
    y_values <- c(y_values, pred$pred, pred$ci_lb, pred$ci_ub)
  }

  x_rng <- range(x_values, na.rm = TRUE)
  y_rng <- range(y_values, na.rm = TRUE)
  x_span <- diff(x_rng)
  y_span <- diff(y_rng)
  if (!is.finite(x_span) || x_span == 0) x_span <- 1
  if (!is.finite(y_span) || y_span == 0) y_span <- 1

  tibble::tibble(
    label_x = x_rng[1] + 0.03 * x_span,
    label_y = y_rng[2] - 0.04 * y_span
  )
}

add_equation_label <- function(plot_obj, label_data, label_size = 3.05) {
  plot_obj +
    geom_label(
      data = label_data,
      aes(x = label_x, y = label_y, label = label),
      inherit.aes = FALSE,
      hjust = 0,
      vjust = 1,
      size = label_size,
      lineheight = 0.92,
      label.size = 0.25,
      label.padding = grid::unit(0.18, "lines"),
      fill = "white",
      colour = "black",
      alpha = 0.90
    ) +
    coord_cartesian(clip = "off")
}

make_selected_dose_plot <- function(result) {
  dat <- result$data_model
  sel <- result$selection
  selected_model <- sel$selected_model_script_default[1]
  mod <- if (selected_model == "quadratic" && !is.null(result$quadratic_reml)) {
    result$quadratic_reml
  } else {
    result$linear_reml
  }

  pred <- predict_meta_model(mod, dat, selected_model)

  subtitle_txt <- if (selected_model == "quadratic") {
    paste0(
      "Selected quadratic: beta2 p = ", format_p(sel$beta2_quadratic_p_value),
      "; Delta AIC(linear - quadratic) = ", format_delta_aic(sel$delta_AIC_linear_minus_quadratic),
      "; turning point = ", sprintf("%.1f", sel$turning_point_dose_percent_replacement), "%"
    )
  } else {
    paste0(
      "Selected linear/parsimony: beta2 p = ", format_p(sel$beta2_quadratic_p_value),
      "; Delta AIC(linear - quadratic) = ", format_delta_aic(sel$delta_AIC_linear_minus_quadratic),
      "; k = ", nrow(dat), "; study clusters = ", n_distinct(dat$study_id)
    )
  }

  eq_label <- make_equation_text(mod, dat, selected_model, sel = sel, brief = FALSE)
  label_data <- get_label_position(dat, pred) %>%
    mutate(label = eq_label)

  p <- ggplot(dat, aes(x = dose, y = yi)) +
    geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.45, colour = "grey45") +
    geom_ribbon(
      data = pred,
      aes(x = dose, ymin = ci_lb, ymax = ci_ub),
      inherit.aes = FALSE,
      fill = selected_ribbon_colour,
      alpha = 0.16
    ) +
    geom_line(
      data = pred,
      aes(x = dose, y = pred),
      inherit.aes = FALSE,
      colour = selected_line_colour,
      linewidth = 1.25
    ) +
    geom_point(aes(size = precision, colour = processing), alpha = 0.82, stroke = 0.25) +
    scale_colour_manual(values = processing_palette, drop = FALSE, name = "BSF processing") +
    scale_size_continuous(
      name = "Precision\n(1/SE)",
      range = c(2.2, 7.0),
      breaks = scales::breaks_pretty(n = 3)
    ) +
    scale_x_continuous(labels = function(x) paste0(x, "%"), breaks = scales::breaks_pretty(n = 6)) +
    labs(
      title = paste0("K dose-response: ", dat$dataset[1], " (", stringr::str_to_title(selected_model), ")"),
      subtitle = subtitle_txt,
      x = moderator_axis_label,
      y = "Effect size for condition factor K (Hedges' g)",
      caption = "Values above 0 indicate higher condition factor in the BSF-replacement group than the control group; values below 0 indicate lower condition factor.\nEquation uses raw x = FM replacement (%). Intercept at x=0 may be extrapolated if 0% is outside the observed dose range. Ribbon = 95% CI."
    ) +
    theme_classic(base_size = 14) +
    theme(
      plot.title = element_text(face = "bold", size = 15),
      plot.subtitle = element_text(size = 11, colour = "grey20"),
      axis.title = element_text(face = "bold"),
      axis.text = element_text(colour = "black"),
      legend.position = "bottom",
      legend.box = "vertical",
      legend.title = element_text(face = "bold"),
      plot.caption = element_text(size = 9, colour = "grey25", hjust = 0),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
      plot.margin = margin(8, 18, 8, 8)
    )

  add_equation_label(p, label_data, label_size = 3.0)
}

make_comparison_plot <- function(result) {
  dat <- result$data_model
  pred_linear <- predict_meta_model(result$linear_reml, dat, "linear") %>%
    mutate(model = "Linear")

  pred_all <- pred_linear
  if (!is.null(result$quadratic_reml)) {
    pred_quad <- predict_meta_model(result$quadratic_reml, dat, "quadratic") %>%
      mutate(model = "Quadratic")
    pred_all <- bind_rows(pred_linear, pred_quad)
  }

  sel <- result$selection

  eq_linear <- make_equation_text(result$linear_reml, dat, "linear", sel = sel, brief = TRUE)
  eq_quad <- make_equation_text(result$quadratic_reml, dat, "quadratic", sel = sel, brief = TRUE)
  eq_label <- paste(
    "x = FM replacement (%)",
    eq_linear,
    eq_quad,
    sep = "\n"
  )
  label_data <- get_label_position(dat, pred_all) %>%
    mutate(label = eq_label)

  p <- ggplot(dat, aes(x = dose, y = yi)) +
    geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.45, colour = "grey45") +
    geom_point(aes(size = precision, colour = processing), alpha = 0.72, stroke = 0.25) +
    geom_line(
      data = pred_all,
      aes(x = dose, y = pred, linetype = model),
      inherit.aes = FALSE,
      colour = "black",
      linewidth = 1.05
    ) +
    scale_colour_manual(values = processing_palette, drop = FALSE, name = "BSF processing") +
    scale_linetype_manual(values = c("Linear" = "solid", "Quadratic" = "longdash"), name = "Candidate model") +
    scale_size_continuous(name = "Precision\n(1/SE)", range = c(2.0, 6.5)) +
    scale_x_continuous(labels = function(x) paste0(x, "%"), breaks = scales::breaks_pretty(n = 6)) +
    labs(
      title = paste0("Linear vs quadratic K dose-response: ", dat$dataset[1]),
      subtitle = paste0(
        "beta2 p = ", format_p(sel$beta2_quadratic_p_value),
        "; Delta AIC(linear - quadratic) = ", format_delta_aic(sel$delta_AIC_linear_minus_quadratic),
        "; default selected model = ", sel$selected_model_script_default
      ),
      x = moderator_axis_label,
      y = "Effect size for condition factor K (Hedges' g)",
      caption = "Both candidate equations use raw x = FM replacement (%). Intercepts at x=0 may be extrapolated if 0% is outside the observed dose range. Use the model-selection CSV for final justification."
    ) +
    theme_classic(base_size = 14) +
    theme(
      plot.title = element_text(face = "bold", size = 15),
      plot.subtitle = element_text(size = 11, colour = "grey20"),
      axis.title = element_text(face = "bold"),
      axis.text = element_text(colour = "black"),
      legend.position = "bottom",
      legend.box = "vertical",
      legend.title = element_text(face = "bold"),
      plot.caption = element_text(size = 9, colour = "grey25", hjust = 0),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
      plot.margin = margin(8, 18, 8, 8)
    )

  add_equation_label(p, label_data, label_size = 2.75)
}

save_plot_pair <- function(plot_obj, filename_base, width = 8.5, height = 6.5) {
  ggsave(
    filename = file.path(out_dir, paste0(filename_base, ".pdf")),
    plot = plot_obj,
    width = width,
    height = height,
    units = "in"
  )
  ggsave(
    filename = file.path(out_dir, paste0(filename_base, ".png")),
    plot = plot_obj,
    width = width,
    height = height,
    units = "in",
    dpi = 600
  )
}

# ---- 4. Read all K datasets ----
k_data <- sheet_info %>%
  mutate(data = pmap(list(sheet, dataset_label, subset_type), read_k_sheet))

# ---- 5. Fit linear and quadratic models for each sheet ----
model_results <- k_data %>%
  mutate(result = map(data, run_model_selection))

selection_table <- bind_rows(map(model_results$result, "selection"))
readr::write_csv(selection_table, file.path(out_dir, "K_linear_vs_quadratic_model_selection.csv"))
print(selection_table)

coefficient_table <- pmap_dfr(
  list(model_results$sheet, model_results$dataset_label, model_results$subset_type, model_results$result),
  function(sheet, dataset_label, subset_type, result) {
    bind_rows(
      extract_model_coefficients(sheet, dataset_label, subset_type, "linear_REML", result$linear_reml, result$data_model),
      extract_model_coefficients(sheet, dataset_label, subset_type, "quadratic_REML", result$quadratic_reml, result$data_model)
    )
  }
)
readr::write_csv(coefficient_table, file.path(out_dir, "K_linear_quadratic_REML_coefficients.csv"))
print(coefficient_table)

# ---- 6. Save individual and combined plots ----
selected_plots <- map(model_results$result, make_selected_dose_plot)
comparison_plots <- map(model_results$result, make_comparison_plot)

pwalk(
  list(selected_plots, model_results$sheet),
  function(plot_obj, sheet) {
    save_plot_pair(plot_obj, paste0(sheet, "_selected_linear_or_quadratic_dose_response"))
  }
)

pwalk(
  list(comparison_plots, model_results$sheet),
  function(plot_obj, sheet) {
    save_plot_pair(plot_obj, paste0(sheet, "_linear_vs_quadratic_comparison"))
  }
)

combined_selected <- patchwork::wrap_plots(selected_plots, ncol = 3, guides = "collect") &
  theme(legend.position = "bottom")
save_plot_pair(combined_selected, "K_all_sheets_selected_linear_or_quadratic_panel", width = 21, height = 7.2)

combined_comparison <- patchwork::wrap_plots(comparison_plots, ncol = 3, guides = "collect") &
  theme(legend.position = "bottom")
save_plot_pair(combined_comparison, "K_all_sheets_linear_vs_quadratic_comparison_panel", width = 21, height = 7.2)

# ---- 7. Descriptive observed-effect-size plot ----
all_data <- bind_rows(k_data$data)

descriptive_plot <- ggplot(all_data, aes(x = dose, y = yi)) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.45, colour = "grey45") +
  geom_point(aes(size = precision, colour = processing), alpha = 0.78) +
  facet_wrap(~ dataset, ncol = 3, scales = "free_y") +
  scale_colour_manual(values = processing_palette, drop = FALSE, name = "BSF processing") +
  scale_size_continuous(name = "Precision\n(1/SE)", range = c(2.0, 6.5)) +
  scale_x_continuous(labels = function(x) paste0(x, "%"), breaks = scales::breaks_pretty(n = 5)) +
  labs(
    title = "Observed condition factor K effect sizes by FM replacement level",
    x = moderator_axis_label,
    y = "Effect size for condition factor K (Hedges' g)",
    caption = "Values above 0 indicate higher condition factor in the BSF-replacement group than the control group. Processing labels are collapsed/standardised by sheet category."
  ) +
  theme_classic(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 15),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(colour = "black"),
    strip.background = element_rect(fill = "grey90", colour = "black"),
    strip.text = element_text(face = "bold"),
    legend.position = "bottom",
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
    plot.caption = element_text(size = 9, colour = "grey25", hjust = 0)
  )

save_plot_pair(descriptive_plot, "K_observed_effect_sizes_by_replacement", width = 14, height = 5.5)

# ---- 8. Save cleaned dataset and biological-review template ----
readr::write_csv(all_data, file.path(out_dir, "K_cleaned_analysis_dataset.csv"))

biological_review_template <- selection_table %>%
  transmute(
    sheet,
    dataset,
    subset_type,
    selected_model_script_default,
    manual_biological_plausibility_review_needed,
    turning_point_dose_percent_replacement,
    biological_plausibility_note,
    researcher_final_biological_decision = "EDIT: plausible / not plausible",
    researcher_final_model_to_report = "EDIT: linear / quadratic",
    manuscript_justification = "EDIT: add biological reason, e.g. optimum or threshold based on nutrition theory and observed dose range"
  )
readr::write_csv(biological_review_template, file.path(out_dir, "K_biological_plausibility_review_template.csv"))

# Export the same model-equation components shown inside the graphs.
make_equation_export_row <- function(mod, dat, model_type, sheet, dataset_label, subset_type) {
  comp <- get_equation_components(mod, dat, model_type)

  if (is.null(comp)) {
    return(tibble::tibble(
      sheet = sheet,
      dataset = dataset_label,
      subset_type = subset_type,
      model = model_type,
      displayed_equation = paste0(stringr::str_to_title(model_type), ": not estimable"),
      centered_intercept_at_mean_dose = NA_real_,
      centered_beta1_per_10pct = NA_real_,
      centered_beta2_per_10pct_squared = NA_real_,
      mean_dose_percent = mean(dat$dose, na.rm = TRUE),
      dose_min_percent = min(dat$dose, na.rm = TRUE),
      dose_max_percent = max(dat$dose, na.rm = TRUE),
      raw_intercept_at_0pct = NA_real_,
      raw_linear_slope_per_1pct = NA_real_,
      raw_quadratic_per_1pct_squared = NA_real_,
      intercept_0pct_observed_or_extrapolated = NA_character_
    ))
  }

  comp %>%
    mutate(
      sheet = sheet,
      dataset = dataset_label,
      subset_type = subset_type,
      displayed_equation = make_equation_text(mod, dat, model_type, brief = TRUE)
    ) %>%
    relocate(sheet, dataset, subset_type, model, displayed_equation)
}

equation_table <- pmap_dfr(
  list(model_results$sheet, model_results$dataset_label, model_results$subset_type, model_results$result),
  function(sheet, dataset_label, subset_type, result) {
    dat <- result$data_model
    bind_rows(
      make_equation_export_row(result$linear_reml, dat, "linear", sheet, dataset_label, subset_type),
      make_equation_export_row(result$quadratic_reml, dat, "quadratic", sheet, dataset_label, subset_type)
    )
  }
)
readr::write_csv(equation_table, file.path(out_dir, "K_displayed_model_equations.csv"))

message("Analysis completed. Outputs saved in: ", normalizePath(out_dir))
