# ============================================================
# CY META-ANALYSIS: SINGLE-AXIS ORCHARD-STYLE MASTER GRAPH
# Dataset: Fish meal replacement by black soldier fly (BSF) meal in rainbow trout
# Outcomes:
#   CY    = carcass yield full dataset
#   CY_PD = carcass yield, partially defatted BSF only
# Effect size: log response ratio, lnRR / ROM
#
# Statistical note:
#   CY_PD is a subgroup of CY. This script therefore fits separate multilevel
#   random-effects models and displays them in one descriptive orchard-style graph.
#   Do not treat CY + CY_PD as independent rows in one inferential model.
# ============================================================

# -----------------------------
# 0. USER SETTINGS
# -----------------------------

possible_files <- c("~/Oncorhynchus mykiss/Biometrices indices.xlsx")

file_path <- possible_files[file.exists(path.expand(possible_files))][1]
if (is.na(file_path) || length(file_path) == 0) {
  message("Excel file not found automatically. Please choose the workbook.")
  file_path <- file.choose()
}
file_path <- path.expand(file_path)

out_dir <- "CY_orchard_single_master_outputs"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

# Plot scale: "lnRR" or "percent".
plot_scale <- "lnRR"

if (plot_scale == "lnRR") {
  x_axis_label <- "lnRR"
} else if (plot_scale == "percent") {
  x_axis_label <- "Percentage change in carcass yield relative to control (%)"
} else {
  stop("plot_scale must be either 'lnRR' or 'percent'.")
}

# Master graph font and layout settings.
master_base_size <- 17
master_title_size <- 20
master_subtitle_size <- 14
master_axis_text_x_size <- 14
master_axis_text_y_size <- 17
master_axis_title_x_size <- 17
master_annotation_size <- 5.0
master_annotation_lineheight <- 0.92
master_legend_title_size <- 14
master_legend_text_size <- 13
master_right_margin <- 220
master_plot_width <- 13
master_plot_height <- 5.3
master_annotation_x_gap <- 0.24
master_right_extra_space <- 0.90

master_order_top_to_bottom <- c(
  "Carcass yield: full dataset",
  "Carcass yield: partially defatted"
)

sheet_info <- tibble::tibble(
  sheet_name = c("CY", "CY_PD"),
  dataset_label = c("Carcass yield: full dataset", "Carcass yield: partially defatted"),
  safe_name = c("CY_full", "CY_partially_defatted"),
  outcome_label = c("Carcass yield", "Carcass yield")
)

# -----------------------------
# 1. PACKAGES
# -----------------------------

library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(purrr)
library(janitor)
library(metafor)
library(ggplot2)
library(readr)
library(tibble)

set.seed(1234)

# -----------------------------
# 2. HELPER FUNCTIONS
# -----------------------------

clean_author_to_study_id <- function(x) {
  x %>%
    as.character() %>%
    stringr::str_replace_all("[()]", "") %>%
    stringr::str_remove("_\\d+$") %>%
    stringr::str_squish()
}

extract_year_from_author <- function(x) {
  suppressWarnings(as.numeric(stringr::str_extract(as.character(x), "(19|20)\\d{2}")))
}

normalise_processing_method <- function(x) {
  y <- stringr::str_squish(as.character(x))
  y <- dplyr::na_if(y, "")
  y_lower <- stringr::str_to_lower(y)

  dplyr::case_when(
    is.na(y) ~ NA_character_,
    stringr::str_detect(y_lower, "partial") ~ "Partially defatted",
    stringr::str_detect(y_lower, "defatted") ~ "Defatted",
    stringr::str_detect(y_lower, "whole|full") ~ "Full fat / whole",
    TRUE ~ y
  )
}

read_clean_outcome_sheet <- function(file_path, sheet_name, dataset_label, outcome_label) {

  raw <- readxl::read_excel(file_path, sheet = sheet_name) %>%
    janitor::clean_names() %>%
    dplyr::select(where(~ !all(is.na(.x))))

  if ("mean" %in% names(raw)) {
    raw <- raw %>% dplyr::rename(mean_exp = mean)
  }

  if (!"bsf_processing_method" %in% names(raw) && "processing_method" %in% names(raw)) {
    raw <- raw %>% dplyr::rename(bsf_processing_method = processing_method)
  }

  if (!"year" %in% names(raw)) {
    raw$year <- extract_year_from_author(raw$author)
  }

  optional_cols <- c("tissue", "colour", "p_value")
  for (nm in optional_cols) {
    if (!nm %in% names(raw)) raw[[nm]] <- NA_character_
  }

  required_cols <- c(
    "details", "author", "bsf_inclusion", "bsf_processing_method", "fm_replacement",
    "mean_exp", "sd_exp", "n_exp",
    "mean_control", "sd_control", "n_control"
  )

  missing_cols <- setdiff(required_cols, names(raw))
  if (length(missing_cols) > 0) {
    stop(
      "Missing required columns in sheet '", sheet_name, "': ",
      paste(missing_cols, collapse = ", ")
    )
  }

  dat <- raw %>%
    mutate(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      outcome_label = outcome_label,
      row_id = dplyr::row_number(),

      details = as.character(details),
      author = as.character(author),
      year = ifelse(is.na(year), extract_year_from_author(author), year),

      study_id = clean_author_to_study_id(author),
      study_id = ifelse(
        is.na(study_id) | study_id == "",
        paste0("unknown_study_", row_id),
        study_id
      ),

      effect_id = paste(sheet_name, row_id, details, author, sep = "__"),
      effect_id = stringr::str_replace_all(effect_id, "[^A-Za-z0-9_]+", "_"),

      processing_method = normalise_processing_method(bsf_processing_method),
      processing_detail = stringr::str_squish(as.character(bsf_processing_method)),
      processing_detail = dplyr::na_if(processing_detail, ""),

      tissue = dplyr::na_if(stringr::str_squish(as.character(tissue)), ""),
      colour_coordinate = dplyr::na_if(stringr::str_squish(as.character(colour)), "")
    ) %>%
    mutate(
      across(
        c(year, bsf_inclusion, fm_replacement, mean_exp, sd_exp, n_exp,
          mean_control, sd_control, n_control),
        ~ suppressWarnings(as.numeric(.x))
      )
    ) %>%
    mutate(
      exclusion_reason = dplyr::case_when(
        is.na(mean_exp) | is.na(mean_control) ~ "missing mean",
        is.na(sd_exp) | is.na(sd_control) ~ "missing SD",
        is.na(n_exp) | is.na(n_control) ~ "missing sample size",
        mean_exp <= 0 | mean_control <= 0 ~ "non-positive mean; lnRR cannot be calculated",
        sd_exp <= 0 | sd_control <= 0 ~ "non-positive SD",
        n_exp <= 1 | n_control <= 1 ~ "sample size <= 1",
        TRUE ~ NA_character_
      )
    )

  list(
    clean_all = dat,
    analysis_data = dat %>% filter(is.na(exclusion_reason)),
    excluded = dat %>% filter(!is.na(exclusion_reason))
  )
}

calculate_rom <- function(dat) {

  metafor::escalc(
    measure = "ROM",
    m1i = mean_exp,
    sd1i = sd_exp,
    n1i = n_exp,
    m2i = mean_control,
    sd2i = sd_control,
    n2i = n_control,
    data = as.data.frame(dat),
    append = TRUE
  ) %>%
    tibble::as_tibble() %>%
    mutate(
      sei = sqrt(vi),
      precision = 1 / sei,
      total_n = n_exp + n_control,
      response_ratio = exp(yi),
      percent_change = (exp(yi) - 1) * 100
    ) %>%
    filter(is.finite(yi), is.finite(vi), vi > 0)
}

fit_intercept_model <- function(dat_es) {

  if (nrow(dat_es) < 3) stop("Too few effect sizes for model.")
  if (dplyr::n_distinct(dat_es$study_id) < 2) stop("Too few study clusters for model.")

  metafor::rma.mv(
    yi = yi,
    V = vi,
    random = list(~ 1 | study_id, ~ 1 | effect_id),
    data = dat_es,
    method = "REML",
    test = "t"
  )
}

transform_x <- function(x) {
  if (plot_scale == "percent") {
    return((exp(x) - 1) * 100)
  }
  x
}

format_estimate_text <- function(est, lb, ub) {
  if (plot_scale == "percent") {
    sprintf("%.2f [%.2f, %.2f]", est, lb, ub)
  } else {
    sprintf("%.3f [%.3f, %.3f]", est, lb, ub)
  }
}

summarise_model <- function(fit, dat_es, sheet_name, dataset_label, outcome_label) {

  sm <- summary(fit)
  pred <- tryCatch(predict(fit), error = function(e) NULL)

  estimate <- as.numeric(sm$beta[1])
  se <- as.numeric(sm$se[1])
  ci_lb <- as.numeric(sm$ci.lb[1])
  ci_ub <- as.numeric(sm$ci.ub[1])
  pval <- as.numeric(sm$pval[1])

  pi_lb <- if (!is.null(pred) && "pi.lb" %in% names(pred)) as.numeric(pred$pi.lb[1]) else NA_real_
  pi_ub <- if (!is.null(pred) && "pi.ub" %in% names(pred)) as.numeric(pred$pi.ub[1]) else NA_real_

  mean_vi <- mean(dat_es$vi, na.rm = TRUE)
  approx_i2_total <- 100 * sum(fit$sigma2, na.rm = TRUE) /
    (sum(fit$sigma2, na.rm = TRUE) + mean_vi)

  tibble::tibble(
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    outcome_label = outcome_label,
    k_effects = nrow(dat_es),
    n_studies = dplyr::n_distinct(dat_es$study_id),

    estimate_lnrr = estimate,
    se = se,
    ci_lb = ci_lb,
    ci_ub = ci_ub,
    p_value = pval,

    prediction_lb = pi_lb,
    prediction_ub = pi_ub,

    response_ratio = exp(estimate),
    percent_change = (exp(estimate) - 1) * 100,

    sigma2_study = ifelse(length(fit$sigma2) >= 1, fit$sigma2[1], NA_real_),
    sigma2_effect = ifelse(length(fit$sigma2) >= 2, fit$sigma2[2], NA_real_),
    approx_i2_total_percent = approx_i2_total
  )
}

save_model_text <- function(fit, dat_es, file_out) {
  capture.output({
    cat("MODEL SUMMARY\n")
    cat("=============\n\n")
    print(summary(fit))

    cat("\n\nDATA SUMMARY\n")
    cat("============\n")
    print(dat_es %>% summarise(
      k_effects = n(),
      n_studies = n_distinct(study_id),
      min_yi = min(yi, na.rm = TRUE),
      max_yi = max(yi, na.rm = TRUE),
      mean_yi = mean(yi, na.rm = TRUE)
    ))
  }, file = file_out)
}

make_qc_tables <- function(cleaned_list) {

  cleaned_all <- dplyr::bind_rows(cleaned_list)

  counts <- cleaned_all %>%
    group_by(sheet_name, dataset_label) %>%
    summarise(
      rows_raw = n(),
      rows_eligible_lnrr = sum(is.na(exclusion_reason)),
      rows_excluded = sum(!is.na(exclusion_reason)),
      n_studies = n_distinct(study_id),
      full_fat_or_whole_rows = sum(processing_method == "Full fat / whole", na.rm = TRUE),
      partially_defatted_rows = sum(processing_method == "Partially defatted", na.rm = TRUE),
      defatted_rows = sum(processing_method == "Defatted", na.rm = TRUE),
      .groups = "drop"
    )

  row_keys <- cleaned_all %>%
    mutate(
      row_key = paste(
        details, author, bsf_inclusion, fm_replacement,
        mean_exp, sd_exp, n_exp, mean_control, sd_control, n_control,
        sep = " | "
      )
    ) %>%
    select(sheet_name, dataset_label, row_key, details, author,
           processing_method, mean_exp, sd_exp, n_exp, mean_control, sd_control, n_control)

  full_keys <- row_keys %>%
    filter(sheet_name == "CY") %>%
    distinct(row_key) %>%
    mutate(in_full_cy = TRUE)

  subgroup_key_check <- row_keys %>%
    filter(sheet_name != "CY") %>%
    left_join(full_keys, by = "row_key") %>%
    mutate(in_full_cy = ifelse(is.na(in_full_cy), FALSE, in_full_cy))

  list(counts = counts, subgroup_key_check = subgroup_key_check)
}

# -----------------------------
# 3. READ DATA AND FIT SEPARATE MODELS
# -----------------------------

all_cleaned <- list()
all_excluded <- list()
all_effect_sizes <- list()
all_fits <- list()
all_model_summaries <- list()
output_index <- list()
model_failures <- list()

for (i in seq_len(nrow(sheet_info))) {

  sheet_name <- sheet_info$sheet_name[i]
  dataset_label <- sheet_info$dataset_label[i]
  safe_name <- sheet_info$safe_name[i]
  outcome_label <- sheet_info$outcome_label[i]

  message("\n============================================================")
  message("Running: ", dataset_label, " [", sheet_name, "]")
  message("============================================================")

  dat_obj <- read_clean_outcome_sheet(file_path, sheet_name, dataset_label, outcome_label)

  all_cleaned[[sheet_name]] <- dat_obj$clean_all
  all_excluded[[sheet_name]] <- dat_obj$excluded

  dat_es <- calculate_rom(dat_obj$analysis_data)
  all_effect_sizes[[sheet_name]] <- dat_es

  effect_file <- file.path(out_dir, paste0("effect_sizes_", safe_name, ".csv"))
  readr::write_csv(dat_es, effect_file)

  fit <- tryCatch(fit_intercept_model(dat_es), error = function(e) e)

  if (inherits(fit, "error")) {
    model_failures[[sheet_name]] <- tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      reason = fit$message,
      k_effects = nrow(dat_es),
      n_studies = dplyr::n_distinct(dat_es$study_id)
    )
    next
  }

  all_fits[[sheet_name]] <- fit

  model_rds <- file.path(out_dir, paste0("model_", safe_name, ".rds"))
  saveRDS(fit, model_rds)

  model_txt <- file.path(out_dir, paste0("model_summary_", safe_name, ".txt"))
  save_model_text(fit, dat_es, model_txt)

  all_model_summaries[[sheet_name]] <- summarise_model(
    fit = fit,
    dat_es = dat_es,
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    outcome_label = outcome_label
  )

  output_index[[sheet_name]] <- tibble::tibble(
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    effect_sizes_csv = effect_file,
    model_rds = model_rds,
    model_summary_txt = model_txt
  )
}

# -----------------------------
# 4. SAVE TABLE OUTPUTS AND QC
# -----------------------------

cleaned_all <- dplyr::bind_rows(all_cleaned)
excluded_all <- dplyr::bind_rows(all_excluded)
effect_sizes_all <- dplyr::bind_rows(all_effect_sizes)
model_summaries <- dplyr::bind_rows(all_model_summaries)
output_file_index <- dplyr::bind_rows(output_index)
model_failures_tbl <- dplyr::bind_rows(model_failures)

qc <- make_qc_tables(all_cleaned)

readr::write_csv(cleaned_all, file.path(out_dir, "cleaned_all_CY_requested_sheets.csv"))
readr::write_csv(excluded_all, file.path(out_dir, "excluded_rows_all_CY_requested_sheets.csv"))
readr::write_csv(effect_sizes_all, file.path(out_dir, "effect_sizes_all_CY_requested_sheets.csv"))
readr::write_csv(model_summaries, file.path(out_dir, "model_summaries_all_CY_requested_sheets.csv"))
readr::write_csv(output_file_index, file.path(out_dir, "output_file_index.csv"))
readr::write_csv(model_failures_tbl, file.path(out_dir, "model_failures.csv"))
readr::write_csv(qc$counts, file.path(out_dir, "QC_sheet_counts.csv"))
readr::write_csv(qc$subgroup_key_check, file.path(out_dir, "QC_subgroup_rows_present_in_full_CY.csv"))

if (nrow(model_summaries) == 0) {
  stop("No models were fitted. Check excluded rows and model_failures.csv.")
}

# -----------------------------
# 5. SINGLE-AXIS MASTER ORCHARD-STYLE GRAPH
# -----------------------------

master_points <- effect_sizes_all %>%
  filter(sheet_name %in% model_summaries$sheet_name) %>%
  mutate(
    dataset_label = factor(dataset_label, levels = rev(master_order_top_to_bottom)),
    x_value = transform_x(yi)
  )

master_summary <- model_summaries %>%
  mutate(
    dataset_label = factor(dataset_label, levels = rev(master_order_top_to_bottom)),
    estimate_plot = transform_x(estimate_lnrr),
    ci_lb_plot = transform_x(ci_lb),
    ci_ub_plot = transform_x(ci_ub),
    pi_lb_plot = transform_x(prediction_lb),
    pi_ub_plot = transform_x(prediction_ub),
    estimate_text = format_estimate_text(estimate_plot, ci_lb_plot, ci_ub_plot),
    k_text = paste0("k = ", k_effects, " (", n_studies, " studies)"),
    right_label_text = paste0(estimate_text, "\n", k_text)
  )

x_raw <- c(
  master_points$x_value,
  master_summary$estimate_plot,
  master_summary$ci_lb_plot,
  master_summary$ci_ub_plot,
  master_summary$pi_lb_plot,
  master_summary$pi_ub_plot,
  0
)
x_raw <- x_raw[is.finite(x_raw)]

x_min <- min(x_raw, na.rm = TRUE)
x_max <- max(x_raw, na.rm = TRUE)
x_range <- x_max - x_min
if (!is.finite(x_range) || x_range <= 0) x_range <- 1

x_right_text <- x_max + master_annotation_x_gap * x_range
x_limits <- c(
  x_min - 0.05 * x_range,
  x_max + master_right_extra_space * x_range
)

precision_breaks <- pretty(master_points$precision, n = 3)
precision_breaks <- precision_breaks[precision_breaks > 0]

set.seed(1234)
master_single_plot <- ggplot() +
  geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.45) +
  geom_segment(
    data = master_summary %>% filter(is.finite(pi_lb_plot), is.finite(pi_ub_plot)),
    aes(x = pi_lb_plot, xend = pi_ub_plot, y = dataset_label, yend = dataset_label),
    linewidth = 0.65
  ) +
  geom_segment(
    data = master_summary,
    aes(x = ci_lb_plot, xend = ci_ub_plot, y = dataset_label, yend = dataset_label),
    linewidth = 2.0
  ) +
  geom_point(
    data = master_points,
    aes(x = x_value, y = dataset_label, size = precision, fill = dataset_label, colour = dataset_label),
    shape = 21,
    alpha = 0.38,
    stroke = 0.4,
    position = position_jitter(width = 0, height = 0.13)
  ) +
  geom_point(
    data = master_summary,
    aes(x = estimate_plot, y = dataset_label, fill = dataset_label),
    shape = 21,
    size = 4.4,
    stroke = 1.0,
    colour = "black"
  ) +
  geom_text(
    data = master_summary,
    aes(x = x_right_text, y = dataset_label, label = right_label_text),
    hjust = 0,
    vjust = 0.5,
    lineheight = master_annotation_lineheight,
    size = master_annotation_size
  ) +
  scale_size_continuous(
    name = "Precision (1/SE)",
    range = c(1.8, 7.0),
    breaks = precision_breaks
  ) +
  guides(fill = "none", colour = "none") +
  coord_cartesian(xlim = x_limits, clip = "off") +
  labs(
    title = "Carcass yield response to BSF meal replacement in rainbow trout",
    subtitle = paste0(
      "Rows are separate multilevel random-effects models; points are individual lnRR values; ",
      "thin line = 95% prediction interval; thick line = 95% CI."
    ),
    x = x_axis_label,
    y = NULL
  ) +
  theme_bw(base_size = master_base_size) +
  theme(
    plot.title = element_text(face = "bold", size = master_title_size),
    plot.subtitle = element_text(size = master_subtitle_size),
    axis.text.x = element_text(size = master_axis_text_x_size),
    axis.text.y = element_text(size = master_axis_text_y_size),
    axis.title.x = element_text(size = master_axis_title_x_size),
    legend.position = "bottom",
    legend.title = element_text(size = master_legend_title_size),
    legend.text = element_text(size = master_legend_text_size),
    panel.grid.minor = element_blank(),
    plot.margin = margin(t = 12, r = master_right_margin, b = 12, l = 12)
  )

master_png <- file.path(out_dir, "MASTER_single_axis_CY_orchard_style.png")
master_pdf <- file.path(out_dir, "MASTER_single_axis_CY_orchard_style.pdf")

ggsave(master_png, plot = master_single_plot,
       width = master_plot_width, height = master_plot_height, dpi = 600)
ggsave(master_pdf, plot = master_single_plot,
       width = master_plot_width, height = master_plot_height)

readr::write_csv(master_points, file.path(out_dir, "MASTER_single_axis_points_used_for_plot.csv"))
readr::write_csv(master_summary, file.path(out_dir, "MASTER_single_axis_model_summaries_used_for_plot.csv"))

# -----------------------------
# 6. OPTIONAL FORMAL MODERATOR MODEL: PROCESSING METHOD FROM FULL CY ONLY
# -----------------------------

if ("CY" %in% names(all_effect_sizes)) {

  cy_full <- all_effect_sizes[["CY"]] %>%
    filter(!is.na(processing_method)) %>%
    mutate(
      processing_method = factor(
        processing_method,
        levels = c("Full fat / whole", "Partially defatted", "Defatted")
      )
    )

  if (nrow(cy_full) >= 3 && n_distinct(cy_full$processing_method) >= 2) {

    fit_processing <- metafor::rma.mv(
      yi = yi,
      V = vi,
      mods = ~ processing_method - 1,
      random = list(~ 1 | study_id, ~ 1 | effect_id),
      data = cy_full,
      method = "REML",
      test = "t"
    )

    saveRDS(
      fit_processing,
      file.path(out_dir, "model_processing_method_moderator_full_CY.rds")
    )

    capture.output(
      {
        cat("PROCESSING METHOD MODERATOR MODEL: FULL CY ONLY\n")
        cat("==============================================\n\n")
        print(summary(fit_processing))
      },
      file = file.path(out_dir, "model_summary_processing_method_moderator_full_CY.txt")
    )
  }
}

# -----------------------------
# 7. FINAL CONSOLE SUMMARY
# -----------------------------

message("\n============================================================")
message("ANALYSIS COMPLETE")
message("============================================================")
message("Input workbook: ", normalizePath(file_path))
message("Output folder: ", normalizePath(out_dir))
message("\nMain single-axis master graph:")
message("1. MASTER_single_axis_CY_orchard_style.png")
message("2. MASTER_single_axis_CY_orchard_style.pdf")
message("\nMain model summary table:")
print(model_summaries)

message("\nQC sheet counts:")
print(qc$counts)

message("\nInterpretation:")
message("lnRR < 0 means BSF diet reduced carcass yield relative to fishmeal control.")
message("lnRR > 0 means BSF diet increased carcass yield relative to fishmeal control.")
message("Percent change = (exp(lnRR) - 1) * 100.")
