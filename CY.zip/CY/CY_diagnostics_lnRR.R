# ============================================================
# CY META-ANALYSIS USING LOG RESPONSE RATIO
# Dataset: Fish meal replacement by black soldier fly (BSF) meal in rainbow trout
# Outcomes:
#   CY    = carcass yield full dataset
#   CY_PD = carcass yield, partially defatted BSF only
# Effect size: log response ratio, lnRR / ROM
# Main model: multilevel random-effects model using metafor::rma.mv()
# Diagnostics: funnel plot, Egger-type test, CR2 Egger test, leave-one-study-out sensitivity
# ============================================================

# -----------------------------
# 0. USER SETTINGS
# -----------------------------

possible_files <- c("~/Oncorhynchus mykiss/Biometrices indices.xlsx")

file_path <- possible_files[file.exists(path.expand(possible_files))][1]
if (is.na(file_path) || length(file_path) == 0) {
  message("Excel file not found automatically. Please choose the workbook.")
  file_path <- file.choose()
}
file_path <- path.expand(file_path)

out_dir <- "CY_data_processing"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

sheet_info <- tibble::tibble(
  sheet_name = c("CY", "CY_PD"),
  dataset_label = c("Carcass yield: full dataset", "Carcass yield: partially defatted"),
  safe_name = c("CY_full", "CY_partially_defatted"),
  outcome_label = c("Carcass yield", "Carcass yield")
)

# Egger tests are weak with small k. This is a warning threshold, not an exclusion rule.
min_k_for_egger_warning <- 10

# -----------------------------
# 1. PACKAGES
# -----------------------------

library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(purrr)
library(janitor)
library(metafor)
library(clubSandwich)
library(ggplot2)
library(readr)
library(tibble)

set.seed(1234)

# -----------------------------
# 2. HELPER FUNCTIONS
# -----------------------------

clean_author_to_study_id <- function(x) {
  x %>%
    as.character() %>%
    stringr::str_replace_all("[()]", "") %>%
    stringr::str_remove("_\\d+$") %>%
    stringr::str_squish()
}

extract_year_from_author <- function(x) {
  suppressWarnings(as.numeric(stringr::str_extract(as.character(x), "(19|20)\\d{2}")))
}

normalise_processing_method <- function(x) {
  y <- stringr::str_squish(as.character(x))
  y <- dplyr::na_if(y, "")
  y_lower <- stringr::str_to_lower(y)

  dplyr::case_when(
    is.na(y) ~ NA_character_,
    stringr::str_detect(y_lower, "partial") ~ "Partially defatted",
    stringr::str_detect(y_lower, "defatted") ~ "Defatted",
    stringr::str_detect(y_lower, "whole|full") ~ "Full fat / whole",
    TRUE ~ y
  )
}

read_clean_outcome_sheet <- function(file_path, sheet_name, dataset_label, outcome_label) {

  raw <- readxl::read_excel(file_path, sheet = sheet_name) %>%
    janitor::clean_names() %>%
    dplyr::select(where(~ !all(is.na(.x))))

  # Rename treatment mean column.
  if ("mean" %in% names(raw)) {
    raw <- raw %>% dplyr::rename(mean_exp = mean)
  }

  # Harmonise possible processing-method column names.
  if (!"bsf_processing_method" %in% names(raw) && "processing_method" %in% names(raw)) {
    raw <- raw %>% dplyr::rename(bsf_processing_method = processing_method)
  }

  # Some colour sheets do not have a Year column. Keep this robust for all biometric sheets.
  if (!"year" %in% names(raw)) {
    raw$year <- extract_year_from_author(raw$author)
  }

  optional_cols <- c("tissue", "colour", "p_value")
  for (nm in optional_cols) {
    if (!nm %in% names(raw)) raw[[nm]] <- NA_character_
  }

  required_cols <- c(
    "details", "author", "bsf_inclusion", "bsf_processing_method", "fm_replacement",
    "mean_exp", "sd_exp", "n_exp",
    "mean_control", "sd_control", "n_control"
  )

  missing_cols <- setdiff(required_cols, names(raw))
  if (length(missing_cols) > 0) {
    stop(
      "Missing required columns in sheet '", sheet_name, "': ",
      paste(missing_cols, collapse = ", ")
    )
  }

  dat <- raw %>%
    mutate(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      outcome_label = outcome_label,
      row_id = dplyr::row_number(),

      details = as.character(details),
      author = as.character(author),
      year = ifelse(is.na(year), extract_year_from_author(author), year),

      study_id = clean_author_to_study_id(author),
      study_id = ifelse(
        is.na(study_id) | study_id == "",
        paste0("unknown_study_", row_id),
        study_id
      ),

      effect_id = paste(sheet_name, row_id, details, author, sep = "__"),
      effect_id = stringr::str_replace_all(effect_id, "[^A-Za-z0-9_]+", "_"),

      processing_method = normalise_processing_method(bsf_processing_method),
      processing_detail = stringr::str_squish(as.character(bsf_processing_method)),
      processing_detail = dplyr::na_if(processing_detail, ""),

      tissue = dplyr::na_if(stringr::str_squish(as.character(tissue)), ""),
      colour_coordinate = dplyr::na_if(stringr::str_squish(as.character(colour)), "")
    ) %>%
    mutate(
      across(
        c(year, bsf_inclusion, fm_replacement, mean_exp, sd_exp, n_exp,
          mean_control, sd_control, n_control),
        ~ suppressWarnings(as.numeric(.x))
      )
    ) %>%
    mutate(
      exclusion_reason = dplyr::case_when(
        is.na(mean_exp) | is.na(mean_control) ~ "missing mean",
        is.na(sd_exp) | is.na(sd_control) ~ "missing SD",
        is.na(n_exp) | is.na(n_control) ~ "missing sample size",
        mean_exp <= 0 | mean_control <= 0 ~ "non-positive mean; lnRR cannot be calculated",
        sd_exp <= 0 | sd_control <= 0 ~ "non-positive SD",
        n_exp <= 1 | n_control <= 1 ~ "sample size <= 1",
        TRUE ~ NA_character_
      )
    )

  list(
    clean_all = dat,
    analysis_data = dat %>% filter(is.na(exclusion_reason)),
    excluded = dat %>% filter(!is.na(exclusion_reason))
  )
}

calculate_rom <- function(dat) {

  metafor::escalc(
    measure = "ROM",
    m1i = mean_exp,
    sd1i = sd_exp,
    n1i = n_exp,
    m2i = mean_control,
    sd2i = sd_control,
    n2i = n_control,
    data = as.data.frame(dat),
    append = TRUE
  ) %>%
    tibble::as_tibble() %>%
    mutate(
      sei = sqrt(vi),
      precision = 1 / sei,
      total_n = n_exp + n_control,
      response_ratio = exp(yi),
      percent_change = (exp(yi) - 1) * 100
    ) %>%
    filter(is.finite(yi), is.finite(vi), vi > 0)
}

fit_multilevel_model <- function(dat_es) {

  if (nrow(dat_es) < 3) {
    stop("Too few effect sizes for a multilevel model.")
  }
  if (dplyr::n_distinct(dat_es$study_id) < 2) {
    stop("Too few independent study clusters for a multilevel model.")
  }

  metafor::rma.mv(
    yi = yi,
    V = vi,
    random = list(~ 1 | study_id, ~ 1 | effect_id),
    data = dat_es,
    method = "REML",
    test = "t"
  )
}

summarise_model <- function(fit, dat_es, sheet_name, dataset_label, outcome_label) {

  sm <- summary(fit)
  pred <- tryCatch(predict(fit), error = function(e) NULL)

  estimate <- as.numeric(sm$beta[1])
  se <- as.numeric(sm$se[1])
  ci_lb <- as.numeric(sm$ci.lb[1])
  ci_ub <- as.numeric(sm$ci.ub[1])
  pval <- as.numeric(sm$pval[1])

  pi_lb <- if (!is.null(pred) && "pi.lb" %in% names(pred)) as.numeric(pred$pi.lb[1]) else NA_real_
  pi_ub <- if (!is.null(pred) && "pi.ub" %in% names(pred)) as.numeric(pred$pi.ub[1]) else NA_real_

  mean_vi <- mean(dat_es$vi, na.rm = TRUE)
  approx_i2_total <- 100 * sum(fit$sigma2, na.rm = TRUE) /
    (sum(fit$sigma2, na.rm = TRUE) + mean_vi)

  tibble::tibble(
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    outcome_label = outcome_label,
    k_effects = nrow(dat_es),
    n_studies = dplyr::n_distinct(dat_es$study_id),

    estimate_lnrr = estimate,
    se = se,
    ci_lb = ci_lb,
    ci_ub = ci_ub,
    p_value = pval,

    prediction_lb = pi_lb,
    prediction_ub = pi_ub,

    response_ratio = exp(estimate),
    percent_change = (exp(estimate) - 1) * 100,

    sigma2_study = ifelse(length(fit$sigma2) >= 1, fit$sigma2[1], NA_real_),
    sigma2_effect = ifelse(length(fit$sigma2) >= 2, fit$sigma2[2], NA_real_),
    approx_i2_total_percent = approx_i2_total
  )
}

save_model_text <- function(fit, dat_es, safe_name, out_dir) {

  txt_file <- file.path(out_dir, paste0("model_summary_", safe_name, ".txt"))

  capture.output({
    cat("MODEL SUMMARY\n")
    cat("=============\n\n")
    print(summary(fit))
    cat("\n\nDATA SUMMARY\n")
    cat("============\n")
    print(dat_es %>% summarise(
      k_effects = n(),
      n_studies = n_distinct(study_id),
      min_yi = min(yi, na.rm = TRUE),
      max_yi = max(yi, na.rm = TRUE),
      mean_yi = mean(yi, na.rm = TRUE)
    ))
  }, file = txt_file)

  txt_file
}

run_egger_multilevel <- function(dat_es, sheet_name, dataset_label) {

  warning_note <- ifelse(
    nrow(dat_es) < min_k_for_egger_warning,
    paste0("Caution: k = ", nrow(dat_es), "; Egger test is weak with small k."),
    "OK"
  )

  if (dplyr::n_distinct(dat_es$study_id) < 3) {
    return(tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      term = NA_character_,
      estimate = NA_real_,
      se = NA_real_,
      statistic = NA_real_,
      p_value = NA_real_,
      ci_lb = NA_real_,
      ci_ub = NA_real_,
      note = "Egger-type model not run: fewer than 3 study clusters"
    ))
  }

  egger_fit <- tryCatch(
    metafor::rma.mv(
      yi = yi,
      V = vi,
      mods = ~ sei,
      random = list(~ 1 | study_id, ~ 1 | effect_id),
      data = dat_es,
      method = "REML",
      test = "t"
    ),
    error = function(e) e
  )

  if (inherits(egger_fit, "error")) {
    return(tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      term = NA_character_,
      estimate = NA_real_,
      se = NA_real_,
      statistic = NA_real_,
      p_value = NA_real_,
      ci_lb = NA_real_,
      ci_ub = NA_real_,
      note = paste("Egger-type model failed:", egger_fit$message)
    ))
  }

  egger_tab <- as.data.frame(coef(summary(egger_fit))) %>%
    tibble::rownames_to_column("term") %>%
    janitor::clean_names()

  if ("tval" %in% names(egger_tab)) egger_tab <- egger_tab %>% rename(statistic = tval)
  if ("zval" %in% names(egger_tab)) egger_tab <- egger_tab %>% rename(statistic = zval)
  if ("pval" %in% names(egger_tab)) egger_tab <- egger_tab %>% rename(p_value = pval)

  egger_tab %>%
    mutate(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      note = dplyr::case_when(
        term == "intrcpt" ~ paste("Intercept. Egger caution:", warning_note),
        term == "sei" ~ paste("SE slope. Significant p-value suggests funnel asymmetry / small-study effect. Egger caution:", warning_note),
        TRUE ~ warning_note
      )
    ) %>%
    select(sheet_name, dataset_label, term, estimate, se, statistic, p_value, ci_lb, ci_ub, note)
}

run_egger_cr2 <- function(dat_es, sheet_name, dataset_label) {

  if (dplyr::n_distinct(dat_es$study_id) < 3) {
    return(tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      term = NA_character_,
      beta = NA_real_,
      SE = NA_real_,
      tstat = NA_real_,
      df = NA_real_,
      p_Satt = NA_real_,
      note = "CR2 Egger test not run: fewer than 3 study clusters"
    ))
  }

  egger_fit <- tryCatch(
    metafor::rma.mv(
      yi = yi,
      V = vi,
      mods = ~ sei,
      random = list(~ 1 | study_id, ~ 1 | effect_id),
      data = dat_es,
      method = "REML",
      test = "t"
    ),
    error = function(e) e
  )

  if (inherits(egger_fit, "error")) {
    return(tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      term = NA_character_,
      beta = NA_real_,
      SE = NA_real_,
      tstat = NA_real_,
      df = NA_real_,
      p_Satt = NA_real_,
      note = paste("CR2 Egger model failed:", egger_fit$message)
    ))
  }

  cr2 <- tryCatch(
    clubSandwich::coef_test(egger_fit, vcov = "CR2", cluster = dat_es$study_id),
    error = function(e) e
  )

  if (inherits(cr2, "error")) {
    return(tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      term = NA_character_,
      beta = NA_real_,
      SE = NA_real_,
      tstat = NA_real_,
      df = NA_real_,
      p_Satt = NA_real_,
      note = paste("CR2 test failed:", cr2$message)
    ))
  }

  as.data.frame(cr2) %>%
    tibble::rownames_to_column("term") %>%
    mutate(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      note = "Cluster-robust CR2 inference for Egger-type model"
    ) %>%
    relocate(sheet_name, dataset_label, term)
}

make_funnel_plot <- function(fit, dat_es, dataset_label, safe_name, out_dir) {

  file_out <- file.path(out_dir, paste0("funnel_", safe_name, ".png"))

  png(filename = file_out, width = 1600, height = 1200, res = 200)

  metafor::funnel(
    x = dat_es$yi,
    sei = sqrt(dat_es$vi),
    xlab = "Log response ratio: lnRR",
    ylab = "Standard error",
    main = paste("Funnel plot:", dataset_label)
  )

  abline(v = as.numeric(coef(fit)[1]), lty = 2)
  abline(v = 0, lty = 3)

  dev.off()

  file_out
}

leave_one_study_out_manual <- function(dat_es, full_fit, sheet_name, dataset_label) {

  full_estimate <- as.numeric(coef(full_fit)[1])
  studies <- sort(unique(dat_es$study_id))

  purrr::map_dfr(studies, function(study_removed) {

    tmp <- dat_es %>% filter(study_id != study_removed)

    if (nrow(tmp) < 3 || dplyr::n_distinct(tmp$study_id) < 2) {
      return(tibble::tibble(
        sheet_name = sheet_name,
        dataset_label = dataset_label,
        omitted_study = study_removed,
        k_effects_remaining = nrow(tmp),
        n_studies_remaining = dplyr::n_distinct(tmp$study_id),
        estimate_lnrr = NA_real_,
        se = NA_real_,
        ci_lb = NA_real_,
        ci_ub = NA_real_,
        percent_change = NA_real_,
        change_from_full = NA_real_,
        note = "Model not run after omission: too few data"
      ))
    }

    fit_tmp <- tryCatch(
      metafor::rma.mv(
        yi = yi,
        V = vi,
        random = list(~ 1 | study_id, ~ 1 | effect_id),
        data = tmp,
        method = "REML",
        test = "t"
      ),
      error = function(e) e
    )

    if (inherits(fit_tmp, "error")) {
      return(tibble::tibble(
        sheet_name = sheet_name,
        dataset_label = dataset_label,
        omitted_study = study_removed,
        k_effects_remaining = nrow(tmp),
        n_studies_remaining = dplyr::n_distinct(tmp$study_id),
        estimate_lnrr = NA_real_,
        se = NA_real_,
        ci_lb = NA_real_,
        ci_ub = NA_real_,
        percent_change = NA_real_,
        change_from_full = NA_real_,
        note = paste("Model failed:", fit_tmp$message)
      ))
    }

    sm <- summary(fit_tmp)
    est <- as.numeric(sm$beta[1])

    tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      omitted_study = study_removed,
      k_effects_remaining = nrow(tmp),
      n_studies_remaining = dplyr::n_distinct(tmp$study_id),
      estimate_lnrr = est,
      se = as.numeric(sm$se[1]),
      ci_lb = as.numeric(sm$ci.lb[1]),
      ci_ub = as.numeric(sm$ci.ub[1]),
      percent_change = (exp(est) - 1) * 100,
      change_from_full = est - full_estimate,
      note = "OK"
    )
  })
}

make_leave_one_out_plot_manual <- function(loo_tbl, full_fit, dataset_label, safe_name, out_dir) {

  loo_plot_dat <- loo_tbl %>%
    filter(is.finite(estimate_lnrr)) %>%
    mutate(omitted_study = reorder(omitted_study, estimate_lnrr))

  if (nrow(loo_plot_dat) == 0) return(NULL)

  full_estimate <- as.numeric(coef(full_fit)[1])

  p <- ggplot(loo_plot_dat, aes(y = omitted_study)) +
    geom_segment(aes(x = ci_lb, xend = ci_ub, yend = omitted_study), linewidth = 0.6) +
    geom_point(aes(x = estimate_lnrr), size = 2) +
    geom_vline(xintercept = full_estimate, linetype = "dashed") +
    geom_vline(xintercept = 0, linetype = "dotted") +
    labs(
      title = paste("Leave-one-study-out sensitivity:", dataset_label),
      subtitle = "Dashed vertical line = full model estimate; dotted line = no effect",
      x = "Log response ratio: lnRR",
      y = "Omitted study"
    ) +
    theme_bw()

  file_out <- file.path(out_dir, paste0("leave_one_out_manual_", safe_name, ".png"))
  ggsave(file_out, plot = p, width = 8, height = max(5, 0.25 * nrow(loo_plot_dat)), dpi = 600)

  file_out
}

make_combined_summary_plot <- function(model_summaries, sheet_info, out_dir) {

  if (nrow(model_summaries) == 0) return(NULL)

  summary_plot_dat <- model_summaries %>%
    mutate(dataset_label = factor(dataset_label, levels = rev(sheet_info$dataset_label)))

  p <- ggplot(summary_plot_dat, aes(y = dataset_label)) +
    geom_segment(
      aes(x = prediction_lb, xend = prediction_ub, yend = dataset_label),
      linewidth = 0.6,
      linetype = "dotted",
      na.rm = TRUE
    ) +
    geom_segment(aes(x = ci_lb, xend = ci_ub, yend = dataset_label), linewidth = 1.2) +
    geom_point(aes(x = estimate_lnrr), size = 3) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    labs(
      title = "Summary of multilevel random-effects models for carcass yield",
      subtitle = "Point = pooled lnRR; thick line = 95% CI; dotted line = 95% prediction interval",
      x = "Log response ratio: lnRR",
      y = NULL
    ) +
    theme_bw()

  file_out <- file.path(out_dir, "combined_summary_all_CY_sheets.png")
  ggsave(file_out, plot = p, width = 8, height = 4.5, dpi = 600)

  p
}

coef_table <- function(fit) {
  as.data.frame(coef(summary(fit))) %>%
    tibble::rownames_to_column("term") %>%
    janitor::clean_names() %>%
    mutate(
      response_ratio = exp(estimate),
      percent_change = (exp(estimate) - 1) * 100
    )
}

save_moderator_model <- function(fit, out_dir, base_name) {
  saveRDS(fit, file.path(out_dir, paste0("model_", base_name, ".rds")))
  capture.output(print(summary(fit)), file = file.path(out_dir, paste0("model_summary_", base_name, ".txt")))
  readr::write_csv(coef_table(fit), file.path(out_dir, paste0("moderator_", base_name, ".csv")))
}

# -----------------------------
# 3. RUN ANALYSIS FOR ALL SHEETS
# -----------------------------

all_cleaned <- list()
all_excluded <- list()
all_effect_sizes <- list()
all_fits <- list()
all_model_summaries <- list()
all_egger <- list()
all_egger_cr2 <- list()
all_loo_manual <- list()
all_output_files <- list()
model_failures <- list()

for (i in seq_len(nrow(sheet_info))) {

  sheet_name <- sheet_info$sheet_name[i]
  dataset_label <- sheet_info$dataset_label[i]
  safe_name <- sheet_info$safe_name[i]
  outcome_label <- sheet_info$outcome_label[i]

  message("\n============================================================")
  message("Running analysis for: ", dataset_label, " [", sheet_name, "]")
  message("============================================================")

  dat_obj <- read_clean_outcome_sheet(
    file_path = file_path,
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    outcome_label = outcome_label
  )

  all_cleaned[[sheet_name]] <- dat_obj$clean_all
  all_excluded[[sheet_name]] <- dat_obj$excluded

  dat_es <- calculate_rom(dat_obj$analysis_data)
  all_effect_sizes[[sheet_name]] <- dat_es

  effect_file <- file.path(out_dir, paste0("effect_sizes_", safe_name, ".csv"))
  readr::write_csv(dat_es, effect_file)

  fit <- tryCatch(fit_multilevel_model(dat_es), error = function(e) e)

  if (inherits(fit, "error")) {
    model_failures[[sheet_name]] <- tibble::tibble(
      sheet_name = sheet_name,
      dataset_label = dataset_label,
      reason = fit$message,
      k_effects = nrow(dat_es),
      n_studies = dplyr::n_distinct(dat_es$study_id)
    )
    next
  }

  all_fits[[sheet_name]] <- fit

  model_rds <- file.path(out_dir, paste0("model_", safe_name, ".rds"))
  saveRDS(fit, model_rds)

  model_txt <- save_model_text(fit, dat_es, safe_name, out_dir)

  all_model_summaries[[sheet_name]] <- summarise_model(
    fit = fit,
    dat_es = dat_es,
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    outcome_label = outcome_label
  )

  funnel_file <- make_funnel_plot(
    fit = fit,
    dat_es = dat_es,
    dataset_label = dataset_label,
    safe_name = safe_name,
    out_dir = out_dir
  )

  all_egger[[sheet_name]] <- run_egger_multilevel(
    dat_es = dat_es,
    sheet_name = sheet_name,
    dataset_label = dataset_label
  )

  all_egger_cr2[[sheet_name]] <- run_egger_cr2(
    dat_es = dat_es,
    sheet_name = sheet_name,
    dataset_label = dataset_label
  )

  loo_tbl <- leave_one_study_out_manual(
    dat_es = dat_es,
    full_fit = fit,
    sheet_name = sheet_name,
    dataset_label = dataset_label
  )

  all_loo_manual[[sheet_name]] <- loo_tbl

  loo_manual_file <- file.path(out_dir, paste0("leave_one_out_manual_", safe_name, ".csv"))
  readr::write_csv(loo_tbl, loo_manual_file)

  loo_manual_plot <- make_leave_one_out_plot_manual(
    loo_tbl = loo_tbl,
    full_fit = fit,
    dataset_label = dataset_label,
    safe_name = safe_name,
    out_dir = out_dir
  )

  all_output_files[[sheet_name]] <- tibble::tibble(
    sheet_name = sheet_name,
    dataset_label = dataset_label,
    effect_sizes_csv = effect_file,
    model_rds = model_rds,
    model_summary_txt = model_txt,
    funnel_png = funnel_file,
    leave_one_out_manual_csv = loo_manual_file,
    leave_one_out_manual_png = loo_manual_plot
  )
}

# -----------------------------
# 4. COMBINE AND SAVE TABLE OUTPUTS
# -----------------------------

cleaned_all <- dplyr::bind_rows(all_cleaned)
excluded_all <- dplyr::bind_rows(all_excluded)
effect_sizes_all <- dplyr::bind_rows(all_effect_sizes)
model_summaries <- dplyr::bind_rows(all_model_summaries)
egger_results <- dplyr::bind_rows(all_egger)
egger_cr2_results <- dplyr::bind_rows(all_egger_cr2)
loo_manual_results <- dplyr::bind_rows(all_loo_manual)
output_file_index <- dplyr::bind_rows(all_output_files)
model_failures_tbl <- dplyr::bind_rows(model_failures)

qc_sheet_counts <- cleaned_all %>%
  group_by(sheet_name, dataset_label) %>%
  summarise(
    rows_raw = n(),
    rows_eligible_lnrr = sum(is.na(exclusion_reason)),
    rows_excluded = sum(!is.na(exclusion_reason)),
    n_studies_raw = n_distinct(study_id),
    .groups = "drop"
  )

readr::write_csv(cleaned_all, file.path(out_dir, "cleaned_all_CY_sheets.csv"))
readr::write_csv(excluded_all, file.path(out_dir, "excluded_rows_all_CY_sheets.csv"))
readr::write_csv(effect_sizes_all, file.path(out_dir, "effect_sizes_all_CY_sheets.csv"))
readr::write_csv(model_summaries, file.path(out_dir, "model_summaries_all_CY_sheets.csv"))
readr::write_csv(egger_results, file.path(out_dir, "egger_multilevel_all_CY_sheets.csv"))
readr::write_csv(egger_cr2_results, file.path(out_dir, "egger_CR2_all_CY_sheets.csv"))
readr::write_csv(loo_manual_results, file.path(out_dir, "leave_one_study_out_manual_all_CY_sheets.csv"))
readr::write_csv(output_file_index, file.path(out_dir, "output_file_index.csv"))
readr::write_csv(model_failures_tbl, file.path(out_dir, "model_failures.csv"))
readr::write_csv(qc_sheet_counts, file.path(out_dir, "QC_sheet_counts.csv"))

combined_plot <- make_combined_summary_plot(model_summaries, sheet_info, out_dir)

# -----------------------------
# 5. OPTIONAL MODERATOR MODELS USING FULL CY SHEET ONLY
# -----------------------------
# CY_PD overlaps with CY. Moderator models should therefore use CY only, not CY + CY_PD together.

if ("CY" %in% names(all_effect_sizes)) {

  cy_full <- all_effect_sizes[["CY"]]

  # Processing method moderator.
  cy_proc <- cy_full %>%
    filter(!is.na(processing_method)) %>%
    mutate(
      processing_method = factor(
        processing_method,
        levels = c("Full fat / whole", "Partially defatted", "Defatted")
      )
    )

  if (nrow(cy_proc) >= 3 && n_distinct(cy_proc$processing_method) >= 2) {

    res_processing <- metafor::rma.mv(
      yi = yi,
      V = vi,
      mods = ~ processing_method - 1,
      random = list(~ 1 | study_id, ~ 1 | effect_id),
      data = cy_proc,
      method = "REML",
      test = "t"
    )

    save_moderator_model(res_processing, out_dir, "full_CY_processing_method")
  }

  # Linear and quadratic dose-response using fishmeal replacement percentage.
  cy_dose <- cy_full %>%
    filter(!is.na(fm_replacement)) %>%
    mutate(
      fm_replacement_centered = fm_replacement - mean(fm_replacement, na.rm = TRUE),
      fm_replacement_centered2 = fm_replacement_centered^2
    )

  if (nrow(cy_dose) >= 3 && length(unique(cy_dose$fm_replacement)) >= 2) {

    res_dose_linear <- metafor::rma.mv(
      yi = yi,
      V = vi,
      mods = ~ fm_replacement_centered,
      random = list(~ 1 | study_id, ~ 1 | effect_id),
      data = cy_dose,
      method = "REML",
      test = "t"
    )

    save_moderator_model(res_dose_linear, out_dir, "full_CY_fm_replacement_linear")

    if (length(unique(cy_dose$fm_replacement)) >= 3) {
      res_dose_quadratic <- metafor::rma.mv(
        yi = yi,
        V = vi,
        mods = ~ fm_replacement_centered + fm_replacement_centered2,
        random = list(~ 1 | study_id, ~ 1 | effect_id),
        data = cy_dose,
        method = "REML",
        test = "t"
      )

      save_moderator_model(res_dose_quadratic, out_dir, "full_CY_fm_replacement_quadratic")
    }
  }
}

# -----------------------------
# 6. FINAL CONSOLE SUMMARY
# -----------------------------

message("\n============================================================")
message("ANALYSIS COMPLETE")
message("============================================================")
message("Input workbook: ", normalizePath(file_path))
message("Output folder: ", normalizePath(out_dir))
message("\nMain model summary table:")
print(model_summaries)

message("\nQC sheet counts:")
print(qc_sheet_counts)

message("\nInterpretation:")
message("lnRR < 0 means BSF diet reduced carcass yield relative to fishmeal control.")
message("lnRR > 0 means BSF diet increased carcass yield relative to fishmeal control.")
message("Percent change = (exp(lnRR) - 1) * 100.")
